<?php
//associative array demo
//array of participant scores

$scores=array(
     "deft"=>'60',
     "toheeb"=>'70',
     "sunmisola"=>'65',
     "Ike"=>'72',
     "segun"=>'50',
     "olad"=>'72',
     "solomon"=>'60',
     "kji"=>'70',
     "emma"=>'55');

echo "<pre>";
print_r($scores);
echo "</pre>";

//echo $scores["olad"];

// foreach($scores as $key => $value){
//  echo $key."got".$value."in php Test <br> ";
// }


?>