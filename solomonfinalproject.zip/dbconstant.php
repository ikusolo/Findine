<?php
//define database connection parameters constants

define("DB_HOST","localhost");
define("DB_USERNAME","root");
define("DB_PASSWORD","");
define("DB_DATABASENAME","restaurant_finder");

//app settings
define("APP_NAME","Findine") 
?>